# 阿晨表情 MCP＋UI 更新包

用途：将当前 stdio 版改成远程 Streamable HTTP MCP，并让 send_sticker 关联一个图片 UI。

## 在现有 Codespaces 项目里安装

1. 下载 `achen-sticker-update.zip`，将 ZIP 文件拖进 Codespaces 左侧文件区，放在 `stickers.json` 同一目录。无需自己逐行改代码。
2. 如果终端还在运行旧服务，按一次 Ctrl+C。确认终端当前目录就是这个项目根目录。
3. 复制执行这一行：

```bash
unzip -p achen-sticker-update.zip install-update.sh | bash
```

脚本会备份原代码、替换完整文件、安装固定依赖、运行测试，然后启动服务。现有 `stickers.json` 和六张 PNG 不会被覆盖。更新包不包含替代图片。

如果缺少 unzip，先运行 `sudo apt-get update && sudo apt-get install -y unzip`；然后执行上面的安装命令。

## 启动后

终端应显示：

```text
Achen Sticker MCP running on port 3000
HTTP MCP: /mcp | 浏览器图片预览: /preview
```

在 PORTS 里确认 3000 的 Visibility 为 Public，复制它当前的 Forwarded Address。不要沿用未确认的旧地址。

- 访问地址根路径 `/`：应显示 `status: ok`、`transport: streamable-http`。
- 访问 `/preview`：应能看到表情库中的第一张原图。这验证图片文件可读取和浏览器能显示；不代表 ChatGPT UI 已验收。
- 创建 ChatGPT MCP 连接时，使用当前转发地址加 `/mcp`，认证选择“无需身份验证”。
- 浏览器直接打开 `/mcp` 得到 405 是预期行为；这个接口通过 POST 与 MCP 客户端通信。

连接后工具列表应有 `hello`、`list_stickers`、`send_sticker`。先请求调用 hello，随后请求“发一张无聊表情包”。ChatGPT 是否能在你使用的窗口显示 UI，需要在这个步骤实际确认。

以后重新启动只需 `npm start`。修改图片或 `stickers.json` 后需重启；改变工具/UI 元数据后还需刷新 ChatGPT 连接。

## 配置与文件

`stickers.json` 保持数组格式，每项的 `file` 对应项目根目录的 PNG：

```json
[{"file":"01_无聊.png","name":"无聊","description":"无聊时使用"}]
```

这是格式示例，无需用它覆盖已有表情库。服务兼容 `title`、`desc` 作为名称、描述的备用字段。

运行时依赖固定为 MCP SDK 1.31.0、zod 3.25.76。UI 使用配套的 MCP Apps SDK 1.7.5，已编译进 ui.html，运行时无需加载外部脚本。`widget.js` 和 `build-ui.mjs` 是可维护的 UI 源码；重新编译时运行 `npm ci` 和 `node build-ui.mjs`。

## 已验证与尚待验证

已在制作环境使用官方 SDK 客户端验证：HTTP 服务、初始化、工具发现、hello、表情列表、PNG 数据返回、UI 资源读取、未授权文件路径拒绝、无效 JSON 和 GET 405。

已在真实 Chromium 浏览器里模拟 MCP Apps 宿主，验证 UI 握手、PNG 解码显示、不同图片切换和取消后的显示状态。测试图片为临时合成样本，不是你现有六张图片。另已验证错误请求路径返回 400，并且服务继续运行。

尚待在你的 Codespaces 公网地址和实际 ChatGPT 窗口验证。服务启动并不等于接入验收完成。

## 如果失败

终端日志会记录 HTTP 方法、路径、RPC 方法、状态码、协议版本和响应类型，例如：

```text
MCP POST /mcp rpc=initialize status=200 protocol=- type=application/json
MCP POST /mcp rpc=tools/list status=200 protocol=2025-11-25 type=application/json
```

保留一次创建对应的完整终端日志；如果有 `MCP error`，连同其后堆栈一起提供。不要先继续修改 session。

旧文件位于安装时输出的 `achen-backup-日期时间` 目录中，可复制回项目根目录恢复原版本。

## 官方参考

- https://github.com/modelcontextprotocol/typescript-sdk/blob/v1.x/src/examples/server/simpleStatelessStreamableHttp.ts
- https://developers.openai.com/plugins/build/chatgpt-ui
- https://developers.openai.com/plugins/deploy/connect-chatgpt
