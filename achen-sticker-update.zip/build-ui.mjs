import { build } from "esbuild";
import { writeFile } from "node:fs/promises";
const result = await build({ entryPoints: ["widget.js"], bundle: true, write: false, format: "iife", platform: "browser", target: "es2020", minify: true });
const script = result.outputFiles[0].text.replace(/<\/script/gi, "<\\/script");
await writeFile("ui.html", `<!doctype html>
<html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<style>:root{color-scheme:light dark}body{margin:0;background:transparent;color:light-dark(#252525,#eee);font:14px system-ui,sans-serif}figure{margin:0;max-width:360px}img{display:block;width:100%;max-height:360px;object-fit:contain}img[hidden]{display:none}figcaption{padding:6px 2px;font-size:12px;opacity:.6;text-align:center}#status{padding:12px}#status[hidden]{display:none}</style></head>
<body><figure><img hidden alt="阿晨表情"><figcaption></figcaption></figure><div id="status" role="status">等我一下…</div>
<!-- PREVIEW_DATA -->
<script>${script}</script></body></html>`);
console.log("Built ui.html; the server needs no external browser scripts.");
