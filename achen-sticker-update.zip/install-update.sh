#!/usr/bin/env bash
set -euo pipefail
archive="${1:-achen-sticker-update.zip}"
if [[ ! -f stickers.json ]]; then
  echo '请在 achen-sticker-mcp 项目根目录运行；这里必须能看到 stickers.json。'
  exit 1
fi
if [[ ! -f "$archive" ]]; then
  echo "没有找到 $archive。先将更新 ZIP 拖进 Codespaces 左侧文件区。"
  exit 1
fi
backup_dir="achen-backup-$(date +%Y%m%d-%H%M%S)"
mkdir -p "$backup_dir"
for file in server.js package.json package-lock.json ui.html test.mjs widget.js build-ui.mjs; do
  if [[ -f "$file" ]]; then cp -p "$file" "$backup_dir/"; fi
done
unzip -o "$archive" server.js package.json package-lock.json ui.html test.mjs widget.js build-ui.mjs README.md -d .
echo "旧文件已备份：$backup_dir"
echo '正在安装固定版本依赖…'
npm ci --omit=dev --no-audit --no-fund
echo '正在验证 HTTP MCP 与 UI 资源…'
npm test
echo '测试通过，启动 3000 端口服务。'
exec npm start
