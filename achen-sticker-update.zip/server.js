import http from "node:http";
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { McpServer } from "@modelcontextprotocol/sdk/server/mcp.js";
import { StreamableHTTPServerTransport } from "@modelcontextprotocol/sdk/server/streamableHttp.js";
import { z } from "zod";

const ROOT = path.dirname(fileURLToPath(import.meta.url));
const UI_URI = "ui://achen/sticker-v2.html";
const UI_MIME = "text/html;profile=mcp-app";
const PORT = Number(process.env.PORT ?? "3000");
const stickers = JSON.parse(fs.readFileSync(path.join(ROOT, "stickers.json"), "utf8"));
if (!Array.isArray(stickers)) throw new Error("stickers.json 必须是数组，每项包含 file 文件名。");
for (const sticker of stickers) {
  if (typeof sticker.file !== "string" || path.basename(sticker.file) !== sticker.file || !/\.png$/i.test(sticker.file)) {
    throw new Error("stickers.json 中的 file 必须是项目根目录里的 PNG 文件名。");
  }
}
const uiHtml = fs.readFileSync(path.join(ROOT, "ui.html"), "utf8");
const readonly = { readOnlyHint: true, destructiveHint: false, openWorldHint: false };

function stickerResult(filename) {
  const sticker = stickers.find(item => item.file === filename);
  if (!sticker) return { isError: true, content: [{ type: "text", text: "没有找到这个表情包。请先调用 list_stickers，使用其中的 file 文件名。" }] };
  let bytes;
  try { bytes = fs.readFileSync(path.join(ROOT, sticker.file)); }
  catch { return { isError: true, content: [{ type: "text", text: `表情图片缺失：${sticker.file}。请将图片放在 server.js 同一目录。` }] }; }
  if (!bytes.subarray(0, 8).equals(Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]))) {
    return { isError: true, content: [{ type: "text", text: `文件不是有效的 PNG：${sticker.file}` }] };
  }
  const name = String(sticker.name ?? sticker.title ?? sticker.file.replace(/^\d+_/, "").replace(/\.png$/i, ""));
  const details = { file: sticker.file, name, description: String(sticker.description ?? sticker.desc ?? "") };
  return {
    structuredContent: details,
    content: [{ type: "text", text: `展示阿晨表情：${name}` }],
    _meta: { sticker: { ...details, dataUrl: "data:image/png;base64," + bytes.toString("base64") } }
  };
}

function createMcpServer() {
  const server = new McpServer(
    { name: "achen-sticker-mcp", version: "0.2.0" },
    { instructions: "Use list_stickers to find an existing sticker and its exact file name. Use send_sticker to display it when the user requests a sticker or a sticker fits the current conversation. Do not invent file names. These tools retrieve existing images; they do not generate new images." }
  );
  server.registerTool("hello", {
    description: "检查阿晨 MCP 是否能够正常调用。", inputSchema: {}, annotations: readonly
  }, async () => ({ content: [{ type: "text", text: "Achen MCP OK" }] }));
  server.registerTool("list_stickers", {
    description: "查看阿晨已有表情包及 file 文件名，选择适合当前聊天语境的一张。", inputSchema: {}, annotations: readonly
  }, async () => ({ content: [{ type: "text", text: JSON.stringify(stickers, null, 2) }] }));
  server.registerResource("achen-sticker-ui", UI_URI, {
    description: "展示现有阿晨表情包的界面。", mimeType: UI_MIME
  }, async () => ({ contents: [{
    uri: UI_URI, mimeType: UI_MIME, text: uiHtml,
    _meta: {
      ui: { prefersBorder: false, csp: { connectDomains: [], resourceDomains: [] } },
      "openai/widgetDescription": "显示本次 send_sticker 选中的现有表情包图片。",
      "openai/widgetPrefersBorder": false
    }
  }] }));
  server.registerTool("send_sticker", {
    title: "阿晨表情包",
    description: "展示一张现有阿晨表情包。用户请求表情，或轻松聊天中适合用表情回应时使用。filename 必须来自 list_stickers 的 file 字段。",
    inputSchema: { filename: z.string().describe("已有表情的完整 file 文件名，例如 01_无聊.png") },
    outputSchema: { file: z.string(), name: z.string(), description: z.string() },
    annotations: readonly,
    _meta: {
      ui: { resourceUri: UI_URI },
      "ui/resourceUri": UI_URI,
      "openai/outputTemplate": UI_URI,
      "openai/toolInvocation/invoking": "找一张表情…",
      "openai/toolInvocation/invoked": "表情来了",
      securitySchemes: [{ type: "noauth" }]
    }
  }, async ({ filename }) => stickerResult(filename));
  return server;
}

async function parseBody(req) {
  const chunks = [];
  let size = 0;
  for await (const chunk of req) {
    size += chunk.length;
    if (size > 1024 * 1024) throw Object.assign(new Error("请求过大"), { status: 413 });
    chunks.push(chunk);
  }
  return JSON.parse(Buffer.concat(chunks).toString("utf8"));
}
function json(res, status, value) {
  res.writeHead(status, { "Content-Type": "application/json; charset=utf-8" });
  res.end(JSON.stringify(value));
}
const httpServer = http.createServer(async (req, res) => {
  let pathname = req.url ?? "/";
  res.setHeader("Access-Control-Allow-Origin", "*");
  res.setHeader("Access-Control-Allow-Headers", "Content-Type, Accept, MCP-Protocol-Version, MCP-Session-Id");
  res.setHeader("Access-Control-Expose-Headers", "MCP-Session-Id");
  let rpcMethod = "-";
  res.on("finish", () => console.log(`MCP ${req.method} ${pathname} rpc=${rpcMethod} status=${res.statusCode} protocol=${req.headers["mcp-protocol-version"] ?? "-"} type=${res.getHeader("content-type") ?? "-"}`));
  try {
    let url;
    try { url = new URL(req.url, "http://localhost"); }
    catch { json(res, 400, { error: "Invalid request path" }); return; }
    pathname = url.pathname;
    if (req.method === "OPTIONS") {
      res.writeHead(204, { "Access-Control-Allow-Methods": "GET, POST, OPTIONS" }); res.end(); return;
    }
    if (pathname === "/" && req.method === "GET") {
      json(res, 200, { status: "ok", server: "achen-sticker-mcp", version: "0.2.0", transport: "streamable-http", mcp: "/mcp", preview: "/preview", stickers: stickers.length }); return;
    }
    if (pathname === "/preview" && req.method === "GET") {
      const result = stickerResult(url.searchParams.get("filename") ?? stickers[0]?.file);
      if (result.isError) { json(res, 404, result); return; }
      const data = JSON.stringify(result._meta.sticker).replace(/</g, "\\u003c");
      const preview = uiHtml.replace("<!-- PREVIEW_DATA -->", `<script>globalThis.__STICKER_PREVIEW__=${data};</script>`);
      res.writeHead(200, { "Content-Type": "text/html; charset=utf-8" }); res.end(preview); return;
    }
    if (pathname !== "/mcp") { json(res, 404, { error: "Not found" }); return; }
    if (req.method !== "POST") {
      res.setHeader("Allow", "POST, OPTIONS");
      json(res, 405, { jsonrpc: "2.0", id: null, error: { code: -32000, message: "This stateless MCP endpoint accepts POST. Use MCP Inspector or ChatGPT to connect." } }); return;
    }
    let body;
    try { body = await parseBody(req); }
    catch (error) { json(res, error.status ?? 400, { jsonrpc: "2.0", id: null, error: { code: -32700, message: "Invalid JSON request" } }); return; }
    rpcMethod = body?.method ?? "-";
    const server = createMcpServer();
    const transport = new StreamableHTTPServerTransport({ sessionIdGenerator: undefined, enableJsonResponse: true });
    res.once("close", () => { void server.close().catch(error => console.error("MCP close:", error.message)); });
    await server.connect(transport);
    await transport.handleRequest(req, res, body);
  } catch (error) {
    console.error("MCP error:", error.stack ?? error.message);
    if (!res.headersSent) json(res, 500, { jsonrpc: "2.0", id: null, error: { code: -32603, message: "Internal server error; see terminal log." } });
    else if (!res.writableEnded) res.end();
  }
});
httpServer.on("error", error => { console.error("HTTP start failed:", error.message); process.exitCode = 1; });
httpServer.listen(PORT, "0.0.0.0", () => {
  console.log(`Achen Sticker MCP running on port ${httpServer.address().port}`);
  console.log("HTTP MCP: /mcp | 浏览器图片预览: /preview");
});
for (const signal of ["SIGINT", "SIGTERM"]) process.once(signal, () => {
  httpServer.close(() => process.exit(0));
});
