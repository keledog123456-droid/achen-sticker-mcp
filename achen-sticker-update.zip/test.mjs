import assert from "node:assert/strict";
import { test } from "node:test";
import { mkdtemp, writeFile, copyFile, symlink, rm } from "node:fs/promises";
import { tmpdir } from "node:os";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { spawn } from "node:child_process";
import net from "node:net";
import http from "node:http";
import { setTimeout as delay } from "node:timers/promises";
import { Client } from "@modelcontextprotocol/sdk/client/index.js";
import { StreamableHTTPClientTransport } from "@modelcontextprotocol/sdk/client/streamableHttp.js";

const root = path.dirname(fileURLToPath(import.meta.url));
const png = Buffer.from("iVBORw0KGgoAAAANSUhEUgAAAEAAAABACAIAAAAlC+aJAAAAY0lEQVR4nO3PQQ3AIADAQEAvX/wiZSJ4XJb0FLTz7jP+bOmAVw1oDWgNaA1oDWgNaA1oDWgNaA1oDWgNaA1oDWgNaA1oDWgNaA1oDWgNaA1oDWgNaA1oDWgNaA1oDWgNaA1oDWgNaA1oDWgNaA1oDWgNaA1oH+MJAkEGtLkhAAAAAElFTkSuQmCC", "base64");
const secondPng = Buffer.from("iVBORw0KGgoAAAANSUhEUgAAAEAAAABACAIAAAAlC+aJAAAAY0lEQVR4nO3PQQ3AIADAQEAgfhCLl4ngcVnSU9DOfe74s6UDXjWgNaA1oDWgNaA1oDWgNaA1oDWgNaA1oDWgNaA1oDWgNaA1oDWgNaA1oDWgNaA1oDWgNaA1oDWgNaA1oDWgNaA1oDWgNaA1oDWgNaA1oDWgfWq+AiT/jCCSAAAAAElFTkSuQmCC", "base64");

async function fixture() {
  const directory = await mkdtemp(path.join(tmpdir(), "achen-mcp-"));
  await writeFile(path.join(directory, "package.json"), '{"type":"module"}');
  await copyFile(path.join(root, "server.js"), path.join(directory, "server.js"));
  try { await copyFile(path.join(root, "ui.html"), path.join(directory, "ui.html")); } catch {}
  await symlink(path.join(root, "node_modules"), path.join(directory, "node_modules"));
  await writeFile(path.join(directory, "stickers.json"), JSON.stringify([
    { file: "01_无聊.png", name: "无聊", description: "测试图片，不是用户的原图" },
    { file: "02_抱抱开心.png", name: "抱抱开心", description: "第二张测试图片" }
  ]));
  await writeFile(path.join(directory, "01_无聊.png"), png);
  await writeFile(path.join(directory, "02_抱抱开心.png"), secondPng);
  const reservation = net.createServer();
  await new Promise(resolve => reservation.listen(0, "127.0.0.1", resolve));
  const port = reservation.address().port;
  await new Promise(resolve => reservation.close(resolve));
  const child = spawn(process.execPath, ["server.js"], {
    cwd: directory, env: { ...process.env, PORT: String(port) }, stdio: ["pipe", "pipe", "pipe"]
  });
  let logs = "";
  child.stdout.on("data", bytes => { logs += bytes; });
  child.stderr.on("data", bytes => { logs += bytes; });
  const base = `http://127.0.0.1:${port}`;
  const stop = async () => {
    if (child.exitCode === null) {
      const exited = new Promise(resolve => child.once("exit", resolve));
      child.kill("SIGTERM");
      await exited;
    }
    await rm(directory, { recursive: true, force: true });
  };
  let health;
  for (let attempt = 0; attempt < 40; attempt++) {
    try { health = await fetch(base, { signal: AbortSignal.timeout(200) }); break; } catch {}
    if (child.exitCode !== null) break;
    await delay(50);
  }
  return { base, health, stop, logs: () => logs };
}

test("HTTP MCP 能初始化、发现工具、取图并提供 UI 资源", async () => {
  const service = await fixture();
  const client = new Client({ name: "achen-verification", version: "1.0.0" });
  try {
    assert.equal(service.health?.status, 200, "服务器必须监听 HTTP；当前 stdio 代码没有 HTTP 入口\n" + service.logs());
    await client.connect(new StreamableHTTPClientTransport(new URL(service.base + "/mcp")));
    const { tools } = await client.listTools();
    assert.ok(tools.some(tool => tool.name === "hello"));
    assert.ok(tools.some(tool => tool.name === "list_stickers"));
    const send = tools.find(tool => tool.name === "send_sticker");
    assert.ok(send, "应提供 send_sticker");
    assert.equal(send.annotations.readOnlyHint, true);
    const uiUri = send._meta?.ui?.resourceUri;
    assert.match(uiUri, /^ui:\/\//, "发送工具必须关联 UI");
    const hello = await client.callTool({ name: "hello", arguments: {} });
    assert.match(hello.content[0].text, /OK/);
    const list = await client.callTool({ name: "list_stickers", arguments: {} });
    assert.ok(list.content[0].text.includes("01_无聊.png"));
    const result = await client.callTool({ name: "send_sticker", arguments: { filename: "01_无聊.png" } });
    assert.equal(result.isError, undefined);
    assert.equal(result.structuredContent.file, "01_无聊.png");
    assert.equal(result._meta.sticker.dataUrl, "data:image/png;base64," + png.toString("base64"));
    const missing = await client.callTool({ name: "send_sticker", arguments: { filename: "../package.json" } });
    assert.equal(missing.isError, true, "应拒绝未列入表情库的路径");
    const ui = await client.readResource({ uri: uiUri });
    assert.equal(ui.contents[0].mimeType, "text/html;profile=mcp-app");
    assert.ok(ui.contents[0].text.length > 100);
    assert.equal((await fetch(service.base + "/mcp")).status, 405);
    const bad = await fetch(service.base + "/mcp", {
      method: "POST", headers: { "Content-Type": "application/json", "Accept": "application/json, text/event-stream" }, body: "{"
    });
    assert.equal(bad.status, 400);
    const malformedStatus = await new Promise(resolve => {
      const request = http.request({ hostname: "127.0.0.1", port: new URL(service.base).port, path: "//[", method: "GET" }, response => {
        response.resume(); resolve(response.statusCode);
      });
      request.on("error", () => resolve(undefined));
      request.end();
    });
    assert.equal(malformedStatus, 400, "错误请求路径必须返回 400，不能终止服务");
    assert.equal((await fetch(service.base)).status, 200, "错误请求之后服务必须仍然可用");
    console.log("PASS: HTTP、MCP 初始化、hello、表情列表、取图、UI 资源、路径拒绝、协议错误状态");
    if (process.env.ACHEN_BROWSER_TEST === "1") {
      const { createRequire } = await import("node:module");
      const require = createRequire(process.env.CODEX_PRIMARY_RUNTIME_NODE_MODULES + "/package.json");
      const { chromium } = require("playwright");
      const browser = await chromium.launch({ headless: true, executablePath: process.env.ACHEN_BROWSER_EXECUTABLE, args: ["--no-sandbox"] });
      try {
        const page = await browser.newPage({ viewport: { width: 500, height: 500 } });
        const errors = [];
        page.on("pageerror", error => errors.push(error.message));
        await page.setContent('<iframe id="app" sandbox="allow-scripts" style="width:420px;height:420px;border:0"></iframe>');
        await page.evaluate(({ html, result }) => {
          const iframe = document.getElementById("app");
          window.addEventListener("message", event => {
            if (event.source !== iframe.contentWindow || event.data?.jsonrpc !== "2.0") return;
            const msg = event.data;
            if (msg.method === "ui/initialize") {
              iframe.contentWindow.postMessage({ jsonrpc: "2.0", id: msg.id, result: {
                protocolVersion: msg.params.protocolVersion,
                hostInfo: { name: "local-test-host", version: "1.0.0" },
                hostCapabilities: {}, hostContext: { theme: "light", displayMode: "inline" }
              } }, "*");
            } else if (msg.method === "ui/notifications/initialized") {
              window.uiReady = true;
              iframe.contentWindow.postMessage({ jsonrpc: "2.0", method: "ui/notifications/tool-result", params: result }, "*");
            }
          });
          iframe.srcdoc = html.replace('<head>', '<head><meta http-equiv="Content-Security-Policy" content="default-src \'none\'; script-src \'unsafe-inline\'; style-src \'unsafe-inline\'; img-src data:">');
        }, { html: ui.contents[0].text, result });
        await page.waitForFunction(() => window.uiReady === true, null, { timeout: 10000 });
        const frame = page.frames().find(frame => frame !== page.mainFrame());
        await frame.waitForFunction(() => {
          const img = document.querySelector("img");
          return img && img.complete && img.naturalWidth > 0 && document.querySelector("figcaption")?.textContent === "无聊";
        }, null, { timeout: 10000 });
        const second = await client.callTool({ name: "send_sticker", arguments: { filename: "02_抱抱开心.png" } });
        await page.evaluate(result => document.getElementById("app").contentWindow.postMessage({
          jsonrpc: "2.0", method: "ui/notifications/tool-result", params: result
        }, "*"), second);
        await frame.waitForFunction(expected => document.querySelector("figcaption")?.textContent === "抱抱开心" && document.querySelector("img")?.src === expected,
          "data:image/png;base64," + secondPng.toString("base64"), { timeout: 10000 });
        await page.screenshot({ path: path.join(root, "ui-test.png") });
        await page.evaluate(() => document.getElementById("app").contentWindow.postMessage({
          jsonrpc: "2.0", method: "ui/notifications/tool-cancelled", params: { reason: "cancelled" }
        }, "*"));
        await frame.waitForFunction(() => document.querySelector("img")?.hidden && !document.querySelector("#status")?.hidden);
        assert.deepEqual(errors, [], "UI 不应出现浏览器脚本异常");
        console.log("PASS: 浏览器模拟 MCP Apps 宿主，UI 握手、PNG 解码显示、切换第二张表情");
      } finally { await browser.close(); }
    }
  } finally {
    await client.close().catch(() => {});
    await service.stop();
  }
});
