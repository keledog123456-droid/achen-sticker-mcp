import { App } from "@modelcontextprotocol/ext-apps";
const image = document.querySelector("img");
const caption = document.querySelector("figcaption");
const status = document.querySelector("#status");
function render(result) {
  if (result?.isError) {
    image.hidden = true; caption.textContent = ""; status.hidden = false;
    status.textContent = result.content?.find(item => item.type === "text")?.text ?? "这张表情暂时没显示出来。"; return;
  }
  const sticker = result?._meta?.sticker ?? result?.sticker;
  if (!sticker || typeof sticker.dataUrl !== "string" || !sticker.dataUrl.startsWith("data:image/png;base64,")) return;
  caption.textContent = String(sticker.name ?? "阿晨表情");
  image.alt = String(sticker.name ?? "阿晨表情");
  image.onload = () => { status.hidden = true; image.hidden = false; };
  image.onerror = () => { status.hidden = false; status.textContent = "这张表情暂时没显示出来。"; image.hidden = true; };
  image.src = sticker.dataUrl;
}
if (globalThis.__STICKER_PREVIEW__) {
  render({ sticker: globalThis.__STICKER_PREVIEW__ });
} else {
  const app = new App({ name: "Achen Sticker", version: "0.2.0" }, {});
  app.ontoolresult = render;
  app.ontoolcancelled = () => {
    image.hidden = true; caption.textContent = "";
    status.hidden = false; status.textContent = "这次先不发表情啦。";
  };
  const legacy = globalThis.openai;
  if (legacy?.toolResponseMetadata) render({ _meta: legacy.toolResponseMetadata });
  window.addEventListener("openai:set_globals", event => {
    const metadata = event.detail?.globals?.toolResponseMetadata;
    if (metadata) render({ _meta: metadata });
  });
  app.connect().catch(error => {
    console.error("Achen UI connection:", error);
    if (image.hidden) status.textContent = "这张表情暂时没显示出来。";
  });
}
